    
#from providers import BarToTradeConverter
#spread = 0.001
#p, o = BarToTradeConverter._zigzag_open_high_low_close(
#                    #0.2, 0.4, 0.1, 0.3, spread)
#                    100.2, 100.4, 100.1, 100.3, spread)
#for i in range(len(p)):
#    print(i, p[i], o[i])
# 0.4   4
# 0.3   5
# 0.2  6
# 0.1-> 11
# 0.05-> 18
# 0.01-> 73
# 0.005-> 144
# 0.001-> 703

from datetime import date, timedelta
from matplotlib import pyplot as plt

#from providers import BinanceMonthlyTradesProvider
#from aggregators import IntervalTradeAggregator
#from actions import BuySellCloseAction
#from rewards import ConstantReward
#from environment import Environment

from providers import BinanceMonthlyTradesProvider
from aggregators import IntervalTradeAggregator
from rewards import ConstantReward
from actions import NoAction
from .environment import Environment
from features import OhlcRatios, TimeEncoder, Scale, Copy

symbol = 'ETHUSDT'
dir = 'D:/data/binance_monthly_trades/'
provider = BinanceMonthlyTradesProvider(data_dir = dir, symbol = symbol,
                date_from = date(2024, 5, 1), date_to = date(2024, 5, 31))

aggregator = IntervalTradeAggregator(method='time',
                interval=1*60, duration=(1, 8*60*60))

features_pipeline = [
    Scale(source=['open', 'high', 'low', 'close', 'volume'], method='zscore', period=64, write_to='state'),
    OhlcRatios(write_to='state'),
    TimeEncoder(source=['time_start'], yday=True, wday=True, tday=True, write_to='state'),
    #Copy(source=['volume'])
]

env = Environment(
    provider=provider,
    aggregator=aggregator,
    features_pipeline=features_pipeline,
    action_scheme=NoAction(),
    reward_scheme=ConstantReward(),
    warm_up_duration=2*60,
    episode_max_duration=None,
    episode_max_steps=1
)

state, frame = env.reset()
print(state)

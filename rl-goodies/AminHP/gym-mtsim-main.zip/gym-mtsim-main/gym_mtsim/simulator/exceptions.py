class SymbolNotFound(Exception):
    pass


class OrderNotFound(Exception):
    pass



__all__ = [
	'heading'
]


def heading(msg):
	line = '-'*50+'\n'
	return f'{line}{msg}\n{line}'


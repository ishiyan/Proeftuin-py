Gettings Started
================

Installation
------------

Gym Trading Env supports Python 3.9+ on Windows, Mac, and Linux. You can install it using pip:

.. code-block:: console

   pip install gym-trading-env

Or using git :

.. code-block:: console
   
   git clone https://github.com/ClementPerroud/Gym-Trading-Env


Import
------

You can import Gym Trading Env with :

.. code-block:: python

   import gym_trading_env
   

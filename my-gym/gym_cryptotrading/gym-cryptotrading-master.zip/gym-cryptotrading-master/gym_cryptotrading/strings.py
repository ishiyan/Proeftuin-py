#actions
DECAY_RATE = 'decay_rate'
LAG = 'lag'
LONG = 'long'
NEUTRAL = 'neutral'
SHORT = 'short'

#weightedPnL
INVALID_DECAY_RATE = 'Invalid Decay Rate'
INVALID_LAG = 'Invalid Lag'

#url
URL = 'http://api.bitcoincharts.com/v1/csv/coinbaseUSD.csv.gz'

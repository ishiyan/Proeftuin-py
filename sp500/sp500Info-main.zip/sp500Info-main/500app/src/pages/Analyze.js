import {AnalyzeExplain} from "../components/analyzeComponents.js";
import React from "react";
import '../index.css';

function Analyze() {
    return (
        <div>
            <AnalyzeExplain />
        </div>
    );
}

export default Analyze;
# sp500_constituents
List of S&amp;P 500 historical constituents from 1996/01/02 to present. CSV format where each date contains a list of the constituents.

## Description of Files

**'sp500_constituents.csv'** current S&P 500 composition from Wikipedia and output from **'sp500.py'**

**'sp_500_historical_components.csv'**  contains historical S&P 500 index membership from 1996 til present. Output from **'sp500.py'**


# rlmbm
Multi-fractional Brownian Motion

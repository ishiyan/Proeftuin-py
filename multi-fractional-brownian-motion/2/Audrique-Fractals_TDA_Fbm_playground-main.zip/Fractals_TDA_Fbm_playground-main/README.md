# Fractals_TDA_Fbm_playground
A notebook where I explore fractals/fractional brownian motion using topological data analysis and some other techniques. This is in no way intended to be optimized code.

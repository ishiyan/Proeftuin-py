from typing import Sequence, Optional, Union

from ..providers import Trade, Candle, Kline
from ..frame import Frame

class Processor(object):
    """
    Base abstract class for IntervalProcessor, ImbalanceProcessor and RunProcessor
    """
    def __init__(self, **kwargs):
        pass
    
    def reset(self):
        raise NotImplementedError()

    def process(self, trades: Sequence[Trade]) -> Optional[Frame]:
        raise NotImplementedError()

    #def aggregate_bars(self, bars: Sequence[Union[Candle, Kline]]) -> Optional[Frame]:
    #    raise NotImplementedError()
    
    def finish(self) -> Optional[Frame]:
        raise NotImplementedError()
    
    @property
    def name(self):
        raise NotImplementedError()

from datetime import date, timedelta
from env_my_intraday import BinanceMonthlyTradesProvider
from env_my_intraday import IntervalProcessor
from env_my_intraday import EMA, Copy, PriceEncoder
from env_my_intraday import BuySellCloseAction
from env_my_intraday import BalanceReward
from env_my_intraday import SingleAgentEnv, MultiAgentEnv

provider = BinanceMonthlyTradesProvider(data_dir='.', symbol='ETHUSDT',
                                  date_from=date(2018, 5, 1), date_to=date(2018, 5, 31))
processor = IntervalProcessor(method='time', interval=5*60)
period = 1000
atr_name = f'ema_{period}_true_range'
features_pipeline = [
    PriceEncoder(source='close', write_to='both'),
    EMA(period=period, source='true_range', write_to='frame'),
    Copy(source=['volume'])
]
action_scheme = BuySellCloseAction()
reward_scheme = BalanceReward(norm_factor=atr_name)
'''
env = SingleAgentEnv(
    provider=provider,
    processor=processor,
    features_pipeline=features_pipeline,
    action_scheme=action_scheme,
    reward_scheme=reward_scheme,
    initial_balance=1000000,
    warm_up_time=timedelta(hours=1)
)
'''
env = MultiAgentEnv(
    n_agents=1,
    provider=provider,
    processor=processor,
    features_pipeline=features_pipeline,
    action_scheme=action_scheme,
    reward_scheme=reward_scheme,
    initial_balance=1000000,
    warm_up_time=timedelta(hours=1)
)

state = env.reset()
while True:
    #env.render('human')
    print(state)
    action = action_scheme.get_random_action()
    state, reward, terminated, truncated, frame = env.step(action)
    if terminated or truncated:
        break
        
env.close()

#SHOULD PATCH ACTIONS TO RETURN A LIST OF ACTIONS
#my-env/first_test.py
#[OrderedDict([('delta_2_close', -1.1400146), ('volume', 372.88362786957805), ('position', 0), ('position_roi', 0), ('profit_factor', 0.0), ('sortino_ratio', 0.0)])]
#Traceback (most recent call last):
#  File "d:\Mbrane\Repos\Proeftuin-py\my-env\first_test.py", line 48, in <module>
#    state, reward, terminated, truncated, frame = env.step(action)
#                                                  ^^^^^^^^^^^^^^^^
#  File "d:\Mbrane\Repos\Proeftuin-py\my-env\env_my_intraday\multi_agent_environment.py", line 454, in step
#    assert isinstance(actions, Sequence) and (len(actions) == len(self.accounts)), f'{actions}'
#                                              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#AssertionError: 1
from typing import Any, Callable, List, MutableSequence, Optional, Sequence, Tuple, Union
from collections import OrderedDict
from numbers import Real
from time import sleep
from datetime import datetime, timedelta
from arrow import Arrow
import logging
import copy

import numpy as np
import gymnasium as gym

from .frame import Frame 
from .providers import Provider, Trade
from .processors import Processor
from .actions import ActionScheme
from .rewards import RewardScheme
from .features import Feature, TradesFeature
from .broker import Broker
from .accounts import Account

class SingleAgentEnv(Broker, gym.Env):
    metadata = {'render.modes': []}

    def __init__(self,
                 provider: Union[Provider, Sequence[Provider]],
                 processor: Processor,
                 action_scheme: ActionScheme,
                 reward_scheme: RewardScheme,
                 features_pipeline: Optional[Sequence[Feature]] = None,
                 initial_balance: Real = 100000,
                 agent_order_delay: Union[Real, timedelta] = 3,
                 broker_order_delay: Union[Real, timedelta] = 0.5,
                 order_luck: float = 0.10,
                 commission: Union[Real, Callable[[str, Real, Real], Real]] = 20,
                 idle_penalty: Optional[float] = 0.01,
                 warm_up_time: Optional[Union[Real, timedelta]] = 10*60,
                 delay_per_second: Optional[float] = None,
                 instant_balance_update=False,
                 max_frames_period=100,
                 max_trades_period=1000,
                 log: Optional[logging.Logger] = None,
                 **kwargs):
        # Initial balance to start trading in new episode
        assert isinstance(initial_balance, Real) and (initial_balance > 0)
        self.initial_balance = initial_balance
        
        # Penalty for not trading: a number or a function
        assert (idle_penalty is None) or isinstance(idle_penalty, float)
        self.idle_penalty = idle_penalty
        
        if warm_up_time is None:
            warm_up_time = timedelta(seconds=0.0)
        elif isinstance(warm_up_time, Real):
            warm_up_time = timedelta(seconds=float(warm_up_time))
        elif isinstance(warm_up_time, timedelta):
            pass
        else:
            raise ValueError('Invalid warm_up_time value')
        assert warm_up_time.total_seconds() >= 0
        self.warm_up_time: timedelta = warm_up_time

        # Setup delay to reduce CPU usage during reset()
        assert ((delay_per_second is None) or
            (isinstance(delay_per_second, float) and (0.0 <= delay_per_second < 1.0)))
        self.delay_per_second = delay_per_second

        # Initialize accounts for all agents
        account = Account(initial_balance=initial_balance) # RISK-FREE RATE????
        
        # Setup logging
        self._log = log if isinstance(log, logging.Logger) else logging.getLogger(self.__class__.__name__)
        
        # Initialize parent Broker class
        super().__init__(account=account,
                         agent_order_delay=agent_order_delay, broker_order_delay=broker_order_delay,
                         order_luck=order_luck, commission=commission,
                         instant_balance_update=instant_balance_update, **kwargs)
        
        # Setup main objects
        if isinstance(provider, Provider):
            self.providers = [provider]
        elif isinstance(provider, Sequence):
            assert len(provider) > 0, 'You should specify at least 1 data provider!'
            assert all([isinstance(p, Provider) for p in provider]), 'Some of objects are not providers!'
            self.providers = provider
        else:
            raise ValueError('Invalid provider argument')
        self.provider: Optional[Provider] = None
        self.processor = processor
        self.action_scheme = action_scheme
        self.reward_scheme = reward_scheme
        self.features_pipeline = features_pipeline
        
        # Keeps list of features which require update on each processed trade
        self.trades_features = []
        
        # Collect all state names
        spaces = OrderedDict()

        # Calculate maximum periods for trades and frames

        # Process features pipeline
        if isinstance(features_pipeline, Sequence):
            # Iterate over features in pipeline
            for feature in features_pipeline:
                # Check if it is a TradesFeature
                if isinstance(feature, TradesFeature):
                    # Add feature to a special list
                    self.trades_features.append(feature)
                    # Check maximum requested trades_period for the feature
                    trades_period = feature.trades_period
                    if isinstance(trades_period, int):
                        pass
                    elif isinstance(trades_period, Sequence):
                        trades_period = max(trades_period)
                    else:
                        trades_period = 0
                    if (max_trades_period is None) or (max_trades_period < trades_period):
                        max_trades_period = trades_period
                # Collect names from feature if they will be written to a state
                for name, space in feature.spaces.items():
                    spaces[name] = space
                # Check maximum requested period for the feature
                frames_period = feature.period
                if isinstance(frames_period, int):
                    pass
                elif isinstance(frames_period, Sequence):
                    frames_period = max(frames_period)
                else:
                    frames_period = 0
                if (max_frames_period is None) or (max_frames_period < frames_period):
                    max_frames_period = frames_period
        
        # Append per-agent specific state fields
        spaces['position'] = gym.spaces.Box(-np.inf, np.inf, (1,))
        spaces['position_roi'] = gym.spaces.Box(-np.inf, np.inf, (1,))
        spaces['profit_factor'] = gym.spaces.Box(0, np.inf, (1,))
        spaces['sortino_ratio'] = gym.spaces.Box(-np.inf, np.inf, (1,))
        
        # Setup maximum requested periods
        self.max_trades_period = max(1000, (max_trades_period or 0))
        self.max_frames_period = max(100, (max_frames_period or 0))
        
        # Setup observation and action spaces
        self.observation_space: gym.spaces.Space = gym.spaces.Dict(spaces)
        self.observation_names = tuple(spaces.keys())
        self.action_space: gym.spaces.Space = action_scheme.space

        # Episode variables
        self.episode_start_datetime: Optional[Union[Arrow, datetime]] = None
        self.episode_max_duration: Optional[timedelta] = None
        self.span_start_time: Optional[Union[Arrow, datetime]] = None
        self.trades: List[Trade] = []
        self.frames: List[Frame] = []
        self.state: Optional[OrderedDict] = None
        self.rng: Optional[np.random.RandomState] = None
        #self.seed()

    def reset(self, seed: int | None = None, options: dict[str, Any] | None = None) -> tuple[np.array, dict[str, Any]]:
        # This should also reset Broker class, which is also a parent class
        # The Broker class should reset account and position
        super().reset(seed=seed, options=options)
        self.action_space.seed(int((self.np_random.uniform(0, seed if seed is not None else 1))))

        self.processor.reset()
        self.action_scheme.reset()
        self.reward_scheme.reset()
        for feature in self.features_pipeline:
            feature.reset()

        # Reset episode variables
        self.episode_start_datetime = None
        self.episode_max_duration = None
        self.span_start_time = None
        self.trades.clear()
        self.frames.clear()

        # Setup random provider
        if len(self.providers) == 1:
            self.provider = self.providers[0]
        else:
            if self.provider is not None:
                self.provider.close()
            self.provider = self.rng.choice(self.providers)

        # Initialize provider for a random or specified date (any other behavior is encoded in **kwargs)
        self.episode_start_datetime = self.provider.reset(
            episode_start_datetime = None,
            episode_min_duration = None,
            rng=self.rng) + self.warm_up_time
        self.episode_max_duration = timedelta(hours=2)
        
        # Important: we should make random initial action,
        # otherwise policy will tend to perform no orders at all!
        action = self.action_scheme.get_random_action()
        self.action_scheme.process_action(broker = self,
            account = self.account, action = action, time = self.episode_start_datetime)

        # Reset span time
        self.span_start_time = Arrow.now()

        # Read first frame
        frame, done = self._get_next_frame()
        if (frame is None) or done:
            raise RuntimeError(f'Failed to get initial state for {self.episode_start_datetime}')

        state = self._make_state()
        return state, frame

    def step(self, action: Any) -> Tuple[Union[OrderedDict, None], float, bool, bool, Union[Frame, None]]:
        # Convert actions to orders
        action_time = self.last_trade.datetime + self.agent_order_delay
        self.action_scheme.process_action(broker = self,
            account = self.account, action = action, time = action_time)
            
        # Read next frame
        frame, truncated = self._get_next_frame()
        if frame is not None:
            # Construct state for the agent
            state = self._make_state()
            truncated = truncated and (state is not None)
        else:
            truncated = True
            state = None
        
        # Apply penalty for not trading, if needed
        if self.idle_penalty is not None:
            penalty = self.idle_penalty * abs(frame.close - frame.open)
            if self.account.position.quantity_signed == 0:
                self.account.balance -= penalty
                    
        # Check for episode completion
        if (not truncated) and (self.episode_max_duration is not None) and (frame.time_end is not None):
            episode_duration = (frame.time_end - self.episode_start_datetime)
            truncated = (episode_duration >= self.episode_max_duration)

        if truncated:
            # Close agent position if done
            account = self.account
            if account.position.quantity_signed != 0:
                operation = 'S' if (account.position.quantity_signed > 0) else 'B'
                amount = abs(account.position.quantity_signed)
                price = self.last_trade.price
                commission = self._get_commission(operation, amount, price)
                account.close_position(price, self.last_trade.datetime, commission)
        elif not self.instant_balance_update:
            self._update_balances(price=self.last_trade.price, dt=self.last_trade.datetime)
            
        reward = self.reward_scheme.get_reward(env = self, account = self.account)

        return state, reward, False, truncated, frame

    def _get_next_frame(self) -> Tuple[Union[Frame, None], bool]:
        # Iterate until the next frame
        frame = None
        truncated = False
        while True:
            try:
                # Read next trade from provider
                trade = next(self.provider)
                # Process trade to update statistics and execute orders
                self.process_trade(trade)
                # Check if this trade belongs to the time period of our interest
                if trade.datetime >= self.episode_start_datetime - self.warm_up_time:
                    # Add trade to the list of trades
                    self.trades.append(trade)
                    # Remove old trade
                    if len(self.trades) > self.max_trades_period + 1:
                        del self.trades[0]
                    # Process trade to construct a frame
                    frame = self.processor.process(self.trades)
                    # Update features which require each trade
                    for feature in self.trades_features:
                        feature.update(self.trades)
                # Perform delay if needed
                if self.delay_per_second is not None:
                    # Calculate how much time have passed
                    span_duration = float((Arrow.now() - self.span_start_time).microseconds)
                    if span_duration >= 1000000.0 * (1.0 - self.delay_per_second):
                        sleep(self.delay_per_second)
                        # Reset span timer
                        self.span_start_time = Arrow.now()
                if frame is not None:
                    self._process_frame(frame)
                    # Return next frame, if its time >= episode_start_datetime
                    if (frame.time_end is not None) and (frame.time_end >= self.episode_start_datetime):
                        break
            except StopIteration:
                # We get here when provider signals there are no more trades to process.
                # Force processor to return any last unfinished frame
                frame = self.processor.finish()
                if frame is not None:
                    self._process_frame(frame)
                truncated = True
                break
        return frame, truncated
    
    def _process_frame(self, frame: Frame):
        # Save new frame
        self.frames.append(frame)
        # Remove old frame
        if len(self.frames) > self.max_frames_period + 1:
            del self.frames[0]
        # Collect state from feature pipeline
        self.state = OrderedDict()
        for feature in self.features_pipeline:
            feature.process(self.frames, self.state)
            
    def _make_state(self) -> OrderedDict:
        assert isinstance(self.state, OrderedDict)
        account = self.account
        agent_state = self.state
        agent_state['position'] = account.position.quantity_signed
        agent_state['position_roi'] = account.position.roi
        agent_state['profit_factor'] = (account.report.profit_factor or 0.0)
        agent_state['sortino_ratio'] = (account.report.sortino_ratio or 0.0)
        return agent_state

    def close(self):
        # Reset broker (it resets accounts)
        super().reset()
        self.provider.close()
        self.provider = None
        self.processor.reset()
        self.action_scheme.reset()
        self.reward_scheme.reset()
        # Reset episode variables
        self.episode_start_datetime = None
        self.episode_max_duration = None
        self.span_start_time = None
        self.trades.clear()
        self.frames.clear()

    def render(self, mode='human'):
        pass
